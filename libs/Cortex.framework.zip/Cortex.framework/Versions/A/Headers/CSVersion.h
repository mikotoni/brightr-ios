#ifndef CSVERSION_H
#define CSVERSION_H

#define SENSE_PLATFORM_VERSION "v2.0.0-8-ga14d1a2-dirty"
#endif
