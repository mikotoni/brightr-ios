//
//  SitStandModule.h
//  Cortex
//
//  Created by Pim Nijdam on 12/10/13.
//  Copyright (c) 2013 Sense Observation Systems BV. All rights reserved.
//

#import "AIModule.h"

@interface SitStandModule : AIModule

@end
