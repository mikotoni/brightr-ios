//
//  TopLocationsModule.h
//  Cortex
//
//  Created by Pim Nijdam on 9/23/13.
//  Copyright (c) 2013 Sense Observation Systems BV. All rights reserved.
//

#import "AIModule.h"

@interface TopLocationsModule : AIModule

@end
